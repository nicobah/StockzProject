package com.example.stockzprojectapp

data class DummyItem(var name: String, var value: Int)